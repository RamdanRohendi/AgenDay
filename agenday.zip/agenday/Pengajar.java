/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenday;

/**
 *
 * @author LENOVO
 */
public interface Pengajar {
    void Mengabsen();
    void Pelajaran();
    void Tugas();
}
