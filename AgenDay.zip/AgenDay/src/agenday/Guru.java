/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenday;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Guru extends WargaSekolah implements Pengajar{
    private String NIP;
    private String mapel;

    @Override
    public void setNIP(String NIP) {
        this.NIP = NIP;
    }

    @Override
    public String getNIP() {
        return NIP;
    }

    @Override
    public void setMapel(String mapel) {
        this.mapel = mapel;
    }

    @Override
    public String getMapel() {
        return mapel;
    }

    @Override
    public void setNama(String Nama) {
        super.setNama(Nama);
    }

    @Override
    public String getNama() {
        return super.getNama();
    }

    @Override
    public void setTanggalahir(String Tanggalahir) {
        super.setTanggalahir(Tanggalahir);
    }

    @Override
    public String getTanggalahir() {
        return super.getTanggalahir();
    }

    @Override
    public void setTempatLahir(String TempatLahir) {
        super.setTempatLahir(TempatLahir);
    }

    @Override
    public String getTempatLahir() {
        return super.getTempatLahir();
    }
    
    @Override
    public void Mengabsen() {}

    @Override
    public void MengisiAgenda(javax.swing.JLabel txtTgl, javax.swing.JTextArea txtCttn) {
        String nip = Main_AgenDay.login.getUser();
        String kd_mapel = "mapel";
        String tanggal = txtTgl.getText();
        String id_kelas = "kelas";
        String cttn = txtCttn.getText();
        String hari = Main_AgenDay.hari_sekarang();
        
        try{
            Statement stmt = Main_AgenDay.con.createStatement();
            String queryguru = "SELECT * FROM guru WHERE NIP = '"+nip+"'";
            String queryajar = "SELECT * FROM jdwl_ajar WHERE NIP = '"+nip+"' AND hari = '"+hari+"'";
            ResultSet rsg = stmt.executeQuery(queryguru);
            while(rsg.next()){
                kd_mapel = rsg.getString("kd_mapel");
            }
            ResultSet rsa = stmt.executeQuery(queryajar);
            while(rsa.next()){
                id_kelas = rsa.getString("id_kelas");
            }
            
            String query = "INSERT INTO agenday (id_kelas,kd_mapel,tanggal,cttn)" + "VALUES"
                    + "('"+id_kelas+"','"+kd_mapel+"','"+tanggal+"','"+cttn+"')";
            System.out.println(query);
            int berhasil = stmt.executeUpdate(query);
            if(berhasil == 1){
                JOptionPane.showMessageDialog(null,"Data Behasil Masuk");
            }else{
                JOptionPane.showMessageDialog(null,"Data Gagal Dimasukan");
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan Pada Database");
        }
    }

    @Override
    public void setTugas(String Tugas) {
        super.setTugas(Tugas);
    }

    @Override
    public String getTugas() {
        return super.getTugas();
    }

    @Override
    public Boolean cekmengisi(String nip, String kelas, String hari) {
        Boolean sudah = true;
        
        try {
            Statement stmt = Main_AgenDay.con.createStatement();
            String query = "SELECT * FROM data_agenda WHERE NIP = '" + nip + "' AND tanggal = '" + hari + "' AND nama_kelas = '" + kelas + "'";
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                if(nip.equals(rs.getString("NIP")) && hari.equals(rs.getString("tanggal")) && kelas.equals(rs.getString("nama_kelas"))){
                    sudah = true;
                }
            }
            else{
                sudah = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sudah;
    }
    
}
